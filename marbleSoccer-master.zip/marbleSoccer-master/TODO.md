#################################################################################
#  NOTE

* Marble.World => Marble.Level
* Marble.pageGameRound = single life/level
* Marble.pageGameMain = all the lives

* stuff which are stateless e.g. keyboard, device orientation, sounds
  * put them in Marble.pageGameMain




#################################################################################
# goto marble pool
* put all the balls on the field
  * create the texture for it
* amount of ball
  * position of balls
  * texture for balls
* make player die if gone in hole
* create the map
  * color of a normal pool
* only a white ball moving
* all the rest are only balls
* contact on bottom red implies death
* good first game

# goto marble soccer
* one ball
* a goal area
* 2 kind of enemys


# DONE continue integration with chrome webstore
* 3 displays
  * nothing if not chrome
  * Chrome WebApp Installed if chrome + already installed
  * Chrome WebApp Available if chrome + not yet installed
* just display a text on bottom right on landing page.
  * it will do for now
  * This is a button
* DONE change device orientation in marbleSoccer.com
  * if G is pressed, enable DeviceOrientation in player control
  * if shift+G is pressed, disable it

