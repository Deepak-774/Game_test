marble game for [learningthreejs](http://learningthreejs.com)
